//
//  ViewController.swift
//  VideoStreaming
//
//  Created by Mac on 30/12/19.
//  Copyright © 2019 Mac. All rights reserved.
//

import UIKit
import AVFoundation
import AVKit
class ViewController: UIViewController {

    @IBAction func playVideo(_ sender: AnyObject) {
        guard let url = URL(string: "https://firebasestorage.googleapis.com/v0/b/videostreaming-a2571.appspot.com/o/Hyundai%20i30%20exteriors%2Cinteriors%20and%20specs%20-%20YouTube.mp4?alt=media&token=9f2cdde7-c446-4ea9-b714-ba377c35a9c9") else {
            return
        }
        let player = AVPlayer(url: url)
        let controller = AVPlayerViewController()
        controller.player = player
        present(controller, animated: true){
            player.play()
        }
    }
}

